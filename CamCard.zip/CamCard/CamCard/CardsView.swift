//
//  CardsView.swift
//  CamCard
//
//  Created by Swati Yerra on 13/08/19.
//  Copyright © 2019 Swati Yerra. All rights reserved.
//

import SwiftUI

struct CardsView : View {
    var cards: [Card] = cardsListData
    var body: some View {

        NavigationView {
            List(cards) { cardItem in
                NavigationButton(destination: CardDetail(card: cardItem)) {
                    HStack {
                        Image(cardItem.cardImage)
                            .cornerRadius(8)
                            .navigationBarTitle(Text("Cards List"))
                        VStack {
                            Text(cardItem.name)
                            Text(cardItem.jobTitle)
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
        }
    }
}

#if DEBUG
struct CardsView_Previews : PreviewProvider {
    static var previews: some View {
        NavigationView { CardsView(cards: cardsListData) }
    }
}
#endif
