//
//  ContentView.swift
//  CamCard
//
//  Created by Swati Yerra on 13/08/19.
//  Copyright © 2019 Swati Yerra. All rights reserved.
//

import SwiftUI

struct ContentView : View {
    var body: some View {
        VStack {
            PresentationButton(destination: CardsView()) {
                Text("View Cards")
            }
            Image("Camcard")
        }
    }
}

#if DEBUG
struct ContentView_Previews : PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
