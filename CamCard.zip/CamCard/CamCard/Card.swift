//
//  Card.swift
//  CamCard
//
//  Created by Swati Yerra on 13/08/19.
//  Copyright © 2019 Swati Yerra. All rights reserved.
//

import SwiftUI

struct Card:Identifiable {
    var id = UUID()
    var name: String
    var jobTitle: String
    var emailId: String
    var phoneNumber: String
    var cardImage: String
}

#if DEBUG
let cardsListData = [
    Card(name: "John Doa", jobTitle: "Associate Engineer", emailId: "johndoa@gmail.com", phoneNumber: "1236547896",cardImage: "JohnDuaCard"),
    Card(name: "Sniffer Doa", jobTitle: "Technical Lead", emailId: "snifferdoa@gmail.com", phoneNumber: "1236547896",cardImage: "SnifferDoaCard"),
    Card(name: "Selena Peter", jobTitle: "Technology Analyst", emailId:  "selenapeter@gmail.com", phoneNumber: "1236547896",cardImage: "JohnDuaCard"),
    Card(name: "Mathew Jobs", jobTitle: "Project Manager", emailId: "mathewjobs@gmail.com", phoneNumber: "1236547896",cardImage: "MathewJobsCard"),
    Card(name: "Thomas Craft", jobTitle: "Associate Lead", emailId: "thomascraft@gmail.com", phoneNumber: "1236547896",cardImage: "ThomasCraftCard")
]
#endif
