//
//  CardDetail.swift
//  CamCard
//
//  Created by Swati Yerra on 13/08/19.
//  Copyright © 2019 Swati Yerra. All rights reserved.
//

import SwiftUI

struct CardDetail : View {
    let card: Card
    var body: some View {
        VStack {
            Image(card.cardImage)
                .aspectRatio(contentMode: .fit)
                .navigationBarTitle(Text(card.name),displayMode: .inline)
            VStack(alignment: .leading) {
                Text(card.name)
                Text(card.jobTitle)
                Text(card.emailId)
                Text(card.phoneNumber)
            }
        }
    }
}
#if DEBUG
struct CardDetail_Previews : PreviewProvider {
    static var previews: some View {
        NavigationView { CardDetail(card: cardsListData[0]) }
    }
}
#endif
